﻿abstract class Animal
{
    public abstract void Voice();
}

class Cat : Animal
{
    public override void Voice()
    {
        Console.WriteLine("Cat voice Meow Meow: ");
    }

}
class Dog : Animal
{
    public override void Voice()
    {
        Console.WriteLine("Dog Voice is bow bow: ");
    }
}

class Lion : Animal
{
    public override void Voice()
    {
        Console.WriteLine("Lion voice is roar roar: ");
    }
}

class MainClass
{
    static void Main()
    {
        Animal[] animals = new Animal[3];
        animals[0] = new Dog();
        animals[1] = new Cat();
        animals[2] = new Lion();

        foreach (Animal a in animals)
        {
            a.Voice();
        }
    }
}