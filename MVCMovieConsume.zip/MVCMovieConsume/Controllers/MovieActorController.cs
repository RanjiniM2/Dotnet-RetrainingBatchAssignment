﻿using Microsoft.AspNetCore.Mvc;
using MVCMoviConsume.Models;
using MVCMovieConsume.Helper;
using Newtonsoft.Json;

namespace MVCMovieConsume.Controllers
{
    public class MovieActorController : Controller
    {
        MovieApi aPI = new MovieApi();
        public async Task<IActionResult> Index()
        {
            List<MovieActor> movieactor = new List<MovieActor>();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.GetAsync("api/MovieActor/GetAllMovieActors");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                movieactor = JsonConvert.DeserializeObject<List<MovieActor>>(results);

            }
            return View(movieactor);
        }
        public async Task<IActionResult> Details(int Id)
        {
            var movieactor = new MovieActor();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.GetAsync($"api/MovieActor/GetMovieActor/{Id}");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                movieactor = JsonConvert.DeserializeObject<MovieActor>(results);
            }
            return View(movieactor);
        }
        public ActionResult create()
        {
            return View();

        }
        [HttpPost]
        public IActionResult create(MovieActor movieactor)
        {
            HttpClient client = aPI.Initial();
            var addTour = client.PostAsJsonAsync<MovieActor>("api/MovieActor/AddMovieActor", movieactor);
            addTour.Wait();
            var result = addTour.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public async Task<IActionResult> Delete(int Id)
        {
            var movieactor = new MovieActor();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.DeleteAsync($"api/MovieActor/DeleteMovieActor/{Id}");
            return RedirectToAction("Index");
        }
    }
}
