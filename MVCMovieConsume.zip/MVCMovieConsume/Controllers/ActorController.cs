﻿using Microsoft.AspNetCore.Mvc;
using MVCMoviConsume.Models;
using MVCMovieConsume.Helper;
using Newtonsoft.Json;

namespace MVCMovieConsume.Controllers
{
    public class ActorController : Controller
    {
        MovieApi aPI = new MovieApi();
        public async Task<IActionResult> Index()
        {
            List<Actor> pkg = new List<Actor>();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.GetAsync("api/Actor/GetAllActors");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                pkg = JsonConvert.DeserializeObject<List<Actor>>(results);

            }
            return View(pkg);
        }
        public async Task<IActionResult> Details(int Id)
        {
            var pkg = new Actor();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.GetAsync($"api/Actor/GetActor/{Id}");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                pkg = JsonConvert.DeserializeObject<Actor>(results);
            }
            return View(pkg);
        }
        public ActionResult create()
        {
            return View();

        }
        [HttpPost]
        public IActionResult create(Actor pkg)
        {
            HttpClient client = aPI.Initial();
            var addTour = client.PostAsJsonAsync<Actor>("api/Actor/AddActor", pkg);
            addTour.Wait();
            var result = addTour.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public async Task<IActionResult> Delete(int Id)
        {
            var pkg = new Actor();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.DeleteAsync($"api/Actor/DeleteActor/{Id}");
            return RedirectToAction("Index");
        }
    }
}
