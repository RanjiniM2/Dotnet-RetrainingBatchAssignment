﻿using Microsoft.AspNetCore.Mvc;
using MVCMoviConsume.Models;
using MVCMovieConsume.Helper;
using Newtonsoft.Json;

namespace MVCMovieConsume.Controllers
{
    public class MovieController : Controller
    {
        MovieApi aPI = new MovieApi();
        public async Task<IActionResult> Index()
        {
            List<MovieDetails> pkg = new List<MovieDetails>();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.GetAsync("api/Movie/GetAllMovies");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                pkg = JsonConvert.DeserializeObject<List<MovieDetails>>(results);

            }
            return View(pkg);
        }
        public async Task<IActionResult> Details(int Id)
        {
            var pkg = new MovieDetails();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.GetAsync($"api/Movie/GetMovie/{Id}");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                pkg = JsonConvert.DeserializeObject<MovieDetails>(results);
            }
            return View(pkg);
        }
        public ActionResult create()
        {
            return View();

        }
        [HttpPost]
        public IActionResult create(MovieDetails pkg)
        {
            HttpClient client = aPI.Initial();
            var addTour = client.PostAsJsonAsync<MovieDetails>("api/Movie/AddMovie", pkg);
            addTour.Wait();
            var result = addTour.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public async Task<IActionResult> Delete(int Id)
        {
            var pkg = new MovieDetails();
            HttpClient client = aPI.Initial();
            HttpResponseMessage res = await client.DeleteAsync($"api/Movie/DeleteMovie/{Id}");
            return RedirectToAction("Index");
        }
    }
}
