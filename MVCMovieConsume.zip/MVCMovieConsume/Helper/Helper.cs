﻿namespace MVCMovieConsume.Helper
{
    public class MovieApi
    {
        public HttpClient Initial()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7194");
            return client;
        }
    }
}
