﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace MVCMoviConsume.Models
{
    public class MovieActor
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int MovieActorId { get; set; }
        [Required(ErrorMessage = "Please enter a Movie Id")]
        [Display(Name = "MovieDetails")]
        public virtual int MovieId { get; set; }

        [ForeignKey("MovieId")]
        public virtual MovieDetails? movies { get; set; }

        [Required(ErrorMessage = "Please enter a Actor Id")]

        [Display(Name = "Actor")]
        public virtual int ActorId { get; set; }

        [ForeignKey("ActorId")]
        public virtual Actor? actors{ get; set; }
    }
}
