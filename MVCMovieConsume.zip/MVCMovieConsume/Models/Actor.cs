﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace MVCMoviConsume.Models
{
    public class Actor
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ActorId { get; set; }
        [Required(ErrorMessage = "Actor Name is Required")]
        public string FirstName { get; set; } = null!;
        [Required(ErrorMessage = "Actor Name is Required")]
        public string LastName { get; set; } = null!;
        public string ?Nationality { get; set; }
       
    }
}
