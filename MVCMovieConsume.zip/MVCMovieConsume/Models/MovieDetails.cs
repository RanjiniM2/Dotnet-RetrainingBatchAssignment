﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace MVCMoviConsume.Models
{
    public class MovieDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int MovieId { get; set; }
        [Required(ErrorMessage = "Movie Name is Required")]
        public string MovieTitle { get; set; } = null!;
        
        [Required(ErrorMessage = "Please enter a Movie Release date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime releaseDate { get; set; }
        [Required(ErrorMessage = "Please enter IMDB Rating")]
        public decimal IMDBRating { get; set; }
        public int duration { get; set; }
    }
}
