﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVCCoreApiAssignment.IRepository;
using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActorController : ControllerBase
    {
        IActorRepository repository;
        public ActorController(IActorRepository _repository)
        {
            repository = _repository;

        }
        [HttpGet]
        [Route("GetAllActors")]
        public async Task<IActionResult> GetAllActors()
        {
            try
            {
                var Actors = await repository.GetAllActors();
                if (Actors == null)
                {
                    return NotFound();
                }
                return Ok(Actors);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPost]
        [Route("AddActor")]
        public async Task<IActionResult> AddActor([FromBody] Actor Actors)
        {

            if (ModelState.IsValid)
            {
                try
                {

                    var ActorId = await repository.AddActor(Actors);
                    if (ActorId > 0)
                    {
                        return Ok(ActorId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpGet]
        [Route("GetActor/{Actorid}")]
        public async Task<IActionResult> GetActor(int? Actorid)
        {
            if (Actorid == null)
            {
                return BadRequest();
            }
            try
            {
                var Actors = await repository.GetActor(Actorid);
                if (Actors == null)
                {
                    return NotFound();
                }
                return Ok(Actors);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("DeleteActor/{Actorid}")]
        public async Task<IActionResult> DeleteActor(int? Actorid)
        {
            int result = 0;
            if (Actorid == null)
            {
                return BadRequest();
            }
            try
            {

                result = await repository.DeleteActor(Actorid);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPut]
        [Route("UpdateActor")]
        public async Task<IActionResult> UpdateActor([FromBody] Actor model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await repository.UpdateActor(model);
                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }
    }
}

