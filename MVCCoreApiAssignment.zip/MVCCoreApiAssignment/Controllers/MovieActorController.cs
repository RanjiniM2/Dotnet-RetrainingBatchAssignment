﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVCCoreApiAssignment.IRepository;
using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieActorController : ControllerBase
    {
        IMovieActorRepository repository;
        public MovieActorController(IMovieActorRepository _repository)
        {
            repository = _repository;

        }
        [HttpGet]
        [Route("GetAllMovieActors")]
        public async Task<IActionResult> GetAllMovieActors()
        {
            try
            {
                var movieactors = await repository.GetAllMovieActors();
                if (movieactors == null)
                {
                    return NotFound();
                }
                return Ok(movieactors);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPost]
        [Route("AddMovieActor")]
        public async Task<IActionResult> AddMovieActor([FromBody] MovieActor movieactors)
        {

            if (ModelState.IsValid)
            {
                try
                {

                    var movieactorId = await repository.AddMovieActor(movieactors);
                    if (movieactorId > 0)
                    {
                        return Ok(movieactorId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpGet]
        [Route("GetMovieActor/{movieactorid}")]
        public async Task<IActionResult> GetMovieActor(int? movieactorid)
        {
            if (movieactorid == null)
            {
                return BadRequest();
            }
            try
            {
                var movies = await repository.GetMovieActor(movieactorid);
                if (movies == null)
                {
                    return NotFound();
                }
                return Ok(movies);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("DeleteMovieActor/{movieactorid}")]
        public async Task<IActionResult> DeleteMovieActor(int? movieactorid)
        {
            int result = 0;
            if (movieactorid == null)
            {
                return BadRequest();
            }
            try
            {

                result = await repository.DeleteMovieActor(movieactorid);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPut]
        [Route("UpdateMovieActor")]
        public async Task<IActionResult> UpdateMovieActor([FromBody] MovieActor model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await repository.UpdateMovieActor(model);
                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }
    }
}

