﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVCCoreApiAssignment.IRepository;
using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        IMovieRepository repository;
        public MovieController(IMovieRepository _repository)
        {
            repository = _repository;

        }
        [HttpGet]
        [Route("GetAllMovies")]
        public async Task<IActionResult> GetAllMovies()
        {
            try
            {
                var movies = await repository.GetAllMovies();
                if (movies == null)
                {
                    return NotFound();
                }
                return Ok(movies);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPost]
        [Route("AddMovie")]
        public async Task<IActionResult> AddMovie([FromBody] MovieDetails movies)
        {

            if (ModelState.IsValid)
            {
                try
                {

                    var movieId = await repository.AddMovie(movies);
                    if (movieId > 0)
                    {
                        return Ok(movieId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpGet]
        [Route("GetMovie/{movieid}")]
        public async Task<IActionResult> GetMovie(int? movieid)
        {
            if (movieid == null)
            {
                return BadRequest();
            }
            try
            {
                var movies = await repository.GetMovie(movieid);
                if (movies == null)
                {
                    return NotFound();
                }
                return Ok(movies);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("DeleteMovie/{movieid}")]
        public async Task<IActionResult> DeleteMovie(int? movieid)
        {
            int result = 0;
            if (movieid == null)
            {
                return BadRequest();
            }
            try
            {

                result = await repository.DeleteMovie(movieid);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPut]
        [Route("UpdateMovie")]
        public async Task<IActionResult> UpdateMovie([FromBody] MovieDetails model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await repository.UpdateMovie(model);
                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }
    }
}
