﻿using Microsoft.EntityFrameworkCore;
using MVCCoreApiAssignment.DataAccessLayer;
using MVCCoreApiAssignment.IRepository;
using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.Repository
{
    public class ActorRepository:IActorRepository
    {
        MovieDbContext movieDal;
      
        public ActorRepository(MovieDbContext _moviedal)
        {
            movieDal = _moviedal;
        }
        public async Task<List<Actor>> GetAllActors()
        {
            if (movieDal != null)
            {
                return await movieDal.actors.ToListAsync();
            }
            return null;
        }
        public async Task<int> AddActor(Actor actor)
        {
            if (movieDal != null)
            {
                await movieDal.actors.AddAsync(actor);
                await movieDal.SaveChangesAsync();
                return actor.ActorId;
            }
            return 0;
        }
        public async Task<Actor> GetActor(int? actorid)
        {
            if (movieDal != null)
            {
                return await (from u in movieDal.actors where u.ActorId == actorid select u).FirstOrDefaultAsync();


            }
            return null;
        }
        public async Task<int> DeleteActor(int? actorid)
        {
            int result = 0;
            if (movieDal != null)
            {
                var actor = await movieDal.actors.FirstOrDefaultAsync(x => x.ActorId == actorid);
                if (actorid != null)
                {
                    movieDal.actors.Remove(actor);
                    result = await movieDal.SaveChangesAsync();
                }
                return result;
            }
            return result;
        }
        public async Task UpdateActor(Actor actor)
        {
            if (movieDal != null)
            {
                movieDal.actors.Update(actor);
                await movieDal.SaveChangesAsync();
            }
        }
    }
}
