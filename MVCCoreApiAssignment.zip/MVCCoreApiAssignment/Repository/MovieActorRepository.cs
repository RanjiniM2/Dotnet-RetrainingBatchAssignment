﻿using Microsoft.EntityFrameworkCore;
using MVCCoreApiAssignment.DataAccessLayer;
using MVCCoreApiAssignment.IRepository;
using MVCCoreApiAssignment.Models;
namespace MVCCoreApiAssignment.Repository
{
    public class MovieActorRepository: IMovieActorRepository
    {
        MovieDbContext movieDal;

        public MovieActorRepository(MovieDbContext _moviedal)
        {
            movieDal = _moviedal;
        }
        public async Task<List<MovieActor>> GetAllMovieActors()
        {
            if (movieDal != null)
            {
                return await movieDal.movieactors.ToListAsync();
            }
            return null;
        }
        public async Task<int> AddMovieActor(MovieActor movieactor)
        {
            if (movieDal != null)
            {
                await movieDal.movieactors.AddAsync(movieactor);
                await movieDal.SaveChangesAsync();
                return movieactor.MovieActorId;
            }
            return 0;
        }
        public async Task<MovieActor> GetMovieActor(int? movieactorid)
        {
            if (movieDal != null)
            {
                return await (from u in movieDal.movieactors where u.MovieActorId == movieactorid select u).FirstOrDefaultAsync();


            }
            return null;
        }
        public async Task<int> DeleteMovieActor(int? movieactorid)
        {
            int result = 0;
            if (movieDal != null)
            {
                var movieactor = await movieDal.movieactors.FirstOrDefaultAsync(x => x.MovieActorId == movieactorid);
                if (movieactorid != null)
                {
                    movieDal.movieactors.Remove(movieactor);
                    result = await movieDal.SaveChangesAsync();
                }
                return result;
            }
            return result;
        }
        public async Task UpdateMovieActor(MovieActor movieactor)
        {
            if (movieDal != null)
            {
                movieDal.movieactors.Update(movieactor);
                await movieDal.SaveChangesAsync();
            }
        }

        
    }
}

