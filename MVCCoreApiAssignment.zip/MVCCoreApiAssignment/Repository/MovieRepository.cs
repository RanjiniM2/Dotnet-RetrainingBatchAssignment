﻿using Microsoft.EntityFrameworkCore;
using MVCCoreApiAssignment.DataAccessLayer;
using MVCCoreApiAssignment.IRepository;
using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.Repository
{
    public class MovieRepository:IMovieRepository
    {
        MovieDbContext movieDal;
       
        public MovieRepository(MovieDbContext _moviedal)
        {
            movieDal = _moviedal;
        }
        public async Task<List<MovieDetails>> GetAllMovies()
        {
            if (movieDal != null)
            {
                return await movieDal.movies.ToListAsync();
            }
            return null;
        }
        public async Task<int> AddMovie(MovieDetails movie)
        {
            if (movieDal != null)
            {
                await movieDal.movies.AddAsync(movie);
                await movieDal.SaveChangesAsync();
                return movie.MovieId;
            }
            return 0;
        }
        public async Task<MovieDetails> GetMovie(int? movieid)
        {
            if (movieDal != null)
            {
                return await (from u in movieDal.movies where u.MovieId == movieid select u).FirstOrDefaultAsync();


            }
            return null;
        }
        public async Task<int> DeleteMovie(int? movieid)
        {
            int result = 0;
            if (movieDal != null)
            {
                var movie = await movieDal.movies.FirstOrDefaultAsync(x => x.MovieId == movieid);
                if (movieid != null)
                {
                    movieDal.movies.Remove(movie);
                    result = await movieDal.SaveChangesAsync();
                }
                return result;
            }
            return result;
        }
        public async Task UpdateMovie(MovieDetails movie)
        {
            if (movieDal != null)
            {
                movieDal.movies.Update(movie);
                await movieDal.SaveChangesAsync();
            }
        }
    }
}
