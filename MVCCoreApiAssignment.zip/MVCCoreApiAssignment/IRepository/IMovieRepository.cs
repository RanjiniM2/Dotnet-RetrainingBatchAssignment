﻿using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.IRepository
{
    public interface IMovieRepository
    {
        Task<int> AddMovie(MovieDetails actordetails);
        Task<List<MovieDetails>> GetAllMovies();

        Task UpdateMovie(MovieDetails actorDetails);
        Task<int> DeleteMovie(int? id);
        Task<MovieDetails> GetMovie(int? id);
    }
}
