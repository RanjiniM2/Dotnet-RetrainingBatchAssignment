﻿using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.IRepository
{
    public interface IMovieActorRepository
    {
        Task<int> AddMovieActor(MovieActor movieactor);
        Task<List<MovieActor>> GetAllMovieActors();

        Task UpdateMovieActor(MovieActor movieactor);
        Task<int> DeleteMovieActor(int? id);
        Task<MovieActor> GetMovieActor(int? id);
    }
}
