﻿using MVCCoreApiAssignment.Models;

namespace MVCCoreApiAssignment.IRepository
{
    public interface IActorRepository
    {
        Task<int> AddActor(Actor actordetails);
        Task<List<Actor>> GetAllActors();

        Task UpdateActor(Actor actorDetails);
        Task<int> DeleteActor(int? id);
        Task<Actor> GetActor(int? id);
    }
}
