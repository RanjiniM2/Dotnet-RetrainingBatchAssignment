﻿using MVCCoreApiAssignment.Models;
using Microsoft.EntityFrameworkCore;

namespace MVCCoreApiAssignment.DataAccessLayer
{
    public class MovieDbContext:DbContext
    {
        public MovieDbContext()
        {
        }
        public MovieDbContext(DbContextOptions<MovieDbContext> options) : base(options)
        {
        }
        public DbSet<MovieDetails> movies { get; set; }
        public DbSet<Actor> actors { get; set; }
        public DbSet<MovieActor> movieactors { get; set; }
    }
}
