﻿using System;

class Account
{
    private static int number;
    private int _accountNumber;
    private string _customerName;
    private int _balance;

    public Account(string name, int amount)
    {
        this._accountNumber = ++number;
        this._customerName = name;
        this._balance = amount;
    }
    public int Balance { get { return this._balance; } }
    public int AccountNumber { get { return this._accountNumber; } }

    public string deposit(int money)
    {
        this._balance = this._balance + money;
        return string.Format("{0} deposited", money);
    }

    public string withdraw(int money)
    {
        if (this._balance >= money)
        {
            this._balance = this._balance - money;
        }
        return string.Format("{0} withdrawn", money);
    }



    public string AccountSummary()
    {
        return String.Format("Account Number : {0} \n Customer Name : {1} \n Account Balance : {2}", this._accountNumber, this._customerName, this._balance);

    }

}



class MainClass
{
    static Account[] account = new Account[10];
    static byte count = 0;
    static Account SearchAccount(int accountNo)
    {
        for(int i=0;i<=count;i++)
        {
            if (account[i].AccountNumber==accountNo)
            {
                return account[i];
            }
        }
        return null;
    }
    static void Main()
    {
        
        byte count = 0, option,transctionCode;
        char choice ;
        Account obj;
        string name;
        int amount;
        Console.WriteLine("1.Create Account \n 2.Perfrom Transaction in Existing Account\n 3.Print your  Account summary\n 4.Exit \n");


        do
        {
            Console.WriteLine("What is your requirement: ");
            option = byte.Parse(Console.ReadLine());
            



            switch (option)
            {
                case 1:
                    
                        Console.Write("Enter Customer Name :");
                        name = Console.ReadLine();
                        Console.Write("Enter Initial Balance:");
                        amount = int.Parse(Console.ReadLine());
                        account[count++] = new Account(name, amount);
                        Console.WriteLine("Congrats your account is Successfully Created your Account number is: {0}", account[count - 1].AccountNumber);
                        break;

                case 2:
                    Console.Write("Enter Account Number :");
                    int accountNumber = int.Parse(Console.ReadLine());
                    obj = SearchAccount(accountNumber);
                    if (obj == null)
                    {
                        Console.WriteLine("Please enter a valid account Number");
                    }
                    else
                    {
                        Console.WriteLine("\n what requirement you want to Perfrom");
                        Console.WriteLine("1. Deposit\n2, Withdraw\n3. Balance Enquiry");
                        Console.WriteLine("Enter Your Transaction code: ");
                        transctionCode = byte.Parse(Console.ReadLine());
                        switch (transctionCode)
                        {
                            case 1:
                                Console.WriteLine("Enter your Deposit amount");
                                amount = int.Parse(Console.ReadLine());
                                obj.deposit(amount);
                                break;
                            case 2:
                                Console.WriteLine("Enter your withdraw amount");
                                amount = int.Parse(Console.ReadLine());
                                obj.withdraw(amount);
                                break;
                            case 3:
                                Console.WriteLine("Account Balance" + obj.Balance);
                                break;
                            case 4:
                                Console.WriteLine(obj.AccountSummary());
                                break;
                        }
                        obj = null;
                    }
                    break;

                case 3:
                    Console.WriteLine();
                    for (int i = 0; i < count; i++)
                    {
                       Console.WriteLine(account[i].AccountSummary());
                    }
                        break;
                    
                 case 4:
                    Console.WriteLine("Thank You");
                    Environment.Exit(0);
                    break;




            }
            Console.WriteLine("Continue?(y/n)");
            choice = char.Parse(Console.ReadLine());
        } while (choice == 'Y' || choice == 'y');
    }

}