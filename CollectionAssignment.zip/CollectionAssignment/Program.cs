﻿using System;
using System.Collections;
using System.Collections.Generic;

public class Emplyoee
{
    public readonly int emplyoeeId;
    public readonly string emplyoeeName;
    public static int Id;

    public Emplyoee(string emplyoeeName)
    {
        this.emplyoeeId = ++Id;
        //this.emplyoeeId = id;
        this.emplyoeeName = emplyoeeName;
    }
    public override string ToString()
    {
        return $"{this.emplyoeeName},{this.emplyoeeId}";
        
    }
}








class MainClass
{
    static void Main()
    {
        ArrayList arrayList = new ArrayList();
        arrayList.Add(new Emplyoee("PRUTHVI"));
        arrayList.Add(new Emplyoee("RAJ"));
        arrayList.Add(new Emplyoee("Nikhil"));
        arrayList.Add(new Emplyoee("Goswami"));

        foreach(Emplyoee item in arrayList)
        {
            Console.WriteLine(item.ToString()); 

        }

        SortedList s1 = new SortedList();
        s1.Add(8, new Emplyoee( "PRITHVI"));
        s1.Add(3, new Emplyoee("Denni"));
        s1.Add(1, new Emplyoee("Rakshitha"));
        s1.Add(5, new Emplyoee("Karthik"));

        Console.WriteLine("********************");

        foreach (Emplyoee i in s1.Values)
        {
            Console.WriteLine(i);
        }


        /*  Emplyoee emplyoees = new Emplyoee("Pruthvi");
          Emplyoee emplyoees1 = new Emplyoee("raj");
          Emplyoee emplyoees2 = new Emplyoee("Vishnu");
          Emplyoee emplyoees3 = new Emplyoee("Bhanu");
          Emplyoee emplyoees4 = new Emplyoee("Manu");*/

        ///Console.WriteLine(  emplyoees);
        Console.WriteLine("********************************");
        List<Emplyoee> list = new List<Emplyoee>();
        list.Add(new Emplyoee("rANJINI"));
        list.Add(new Emplyoee("cHANDAN"));
        list.Add(new Emplyoee("mUKESH"));
        list.Add(new Emplyoee("naaveena"));
        list.Add(new Emplyoee("kunti"));

        foreach(Emplyoee i in list)
        {
            Console.WriteLine(i);
        }

        Console.WriteLine("********************************");

        Hashtable hash = new Hashtable();
        hash.Add(9,new Emplyoee("JohnyWalker"));
        hash.Add(3,new Emplyoee("Black & White"));
        hash.Add(1,new Emplyoee("MagicMoment"));
        hash.Add(4,new Emplyoee("OldMonk"));


        


        foreach (Emplyoee s in hash.Values)
        {
            Console.WriteLine(s);
        }
    }
}